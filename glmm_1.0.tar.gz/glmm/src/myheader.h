
#ifndef GLMM_MYHEADER_H
#define GLMM_MYHEADER_H

#define BERNOULLI 1
#define POISSON 2

double cum(double eta, int type);
double cp(double eta, int type);
double cpp(double mu, int type);

#include <math.h>

#endif /* GLMM_MYHEADER_H */

